The program supports the communication between an MSP430F169 and 
an EEPROM 24AA128. 

To setup the project add the following files to the IAR Embedded 
Workbench project:
		    - Main.c
		    - I2Croutines.c





